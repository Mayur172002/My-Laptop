import Basic_task from "./Feature/Basic_task/Basic_task";

function App() {
  return (
    <div >
       <Basic_task/>
    </div>
  );
}

export default App;
