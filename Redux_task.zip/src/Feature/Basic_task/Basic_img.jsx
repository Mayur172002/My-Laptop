import React from 'react'

function Basic_img() {
  return (
    <div>
        <img src="https://tse2.mm.bing.net/th?id=OIP.G37tgeQqSNt7v2oPfj9ltQHaE7&pid=Api&P=0&h=180" alt=""  width='200px'/>
    </div>
  )
}

export default Basic_img