import { createSlice } from "@reduxjs/toolkit";

export const Basic_slice = createSlice({
    name : 'Basic_slice',
    initialState:{
        name:"Mayur",
        number:1,
        isImage:true
    },
    reducers:{
      Change:(state)=>{
       return{...state,name : "Mayur Bhaliya"}
      },
      Plus: (state)=>{
      return{...state,number: state.number + 1} 
      },
      Minus: (state)=>{
        if(state.number > 0){
            return{...state,number: state.number - 1} 
        }
      },
      Hide: (state)=>{
        return{...state,isImage : false} 
      },
      Show: (state)=>{
        return{...state,isImage : true} 
      },
      Toggle: (state)=>{
        return{...state,isImage : !state.isImage} 
      },
    },
    // extraReducers : {

    // }
})

export const  {Change,Plus,Minus,Hide,Show,Toggle}=Basic_slice.actions
export default Basic_slice.reducer